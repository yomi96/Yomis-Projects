$('#jslider').cycle({ 
    fx:     'scrollHorz', 
    speed:  'slow',  
    next:   '#next', 
    prev:   '#prev' 
});