// helper to return only unique values in an array


	
	
Array.prototype.unique = function () {
    var o = {}, i, l = this.length,
        r = [];
    for (i = 0; i < l; i += 1) o[this[i]] = this[i];
    for (i in o) r.push(o[i]);
    return r;
};



$('#boundList').attr("disabled", true);

$(document).ready(function () {
    var img = $('img'), 
        list = $('#boundList');
		
		

    // get each unique value of attribute "value" from the areas;
    // sort them; then generate an unordered list from these values.
    // add an attribute "value='????'" to each one to bind to the map
    // key
    
    var states = Array.prototype.map.call($('area'),   
    function (e) {
        return e.getAttribute('value');
    }).unique()
        .sort()
        .forEach(function (e) {
        var el = $('<option />'	).attr('value', e).text(e);
        list.append(el);
		
    });                  

	
	

	
    
    
    // bind selection of a location to the Select we created. The "listSelectedClass"
    // option causes the class "selected" to be added or removed
    // from the element in "boundList" whose "value" attribute has a value
    // matching the mapKey for the selected area. 
    
    img.mapster({
        mapKey: 'value',
		singleSelect: true,
		isSelectable: false,
		 fillColor: "1282D0",
        boundList: list.find('option'),
        listKey: 'value',
		
		

        listSelectedClass: 'selected'
    });
    
    // bind click event 
    
    $(document).on('click','#boundList option',function(e) {
       
        var el = $(e.target);
		
        el.toggleClass('selected');
        debugger;
        img.mapster('set',null,el.attr('value')); 
        // changing selections manually doesn't result in the boundList
        // being fired, we still have to set the location on the option
		
		
  
    
        
        img.mapster('set',false,img.mapster('get'));
    });

});


