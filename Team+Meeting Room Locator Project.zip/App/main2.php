<!-- Author - Yomi, Keith -->

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 

<html xmlns = "http://www.w3.org/1999/xhtml">

<head>

<title> Map Page </title>

<script type="text/javascript" src="javascript/Function.js"></script>
<link href="css/style3.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="JavaScript/jquery.min.js"></script>
<link href="css/style2.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="JavaScript/jquery.imagemapster.js"></script>
<script type="text/javascript" src="JavaScript/FunctionMap.js"></script>
<script type="text/javascript" src="JavaScript/FunctionMapRoom.js"></script>


</head>




<body>
 <div class="container">
 
<div id="wrapper">

		<div id="header"> 
		
		<img src="sap.png" alt="Logo" style="width:151px;height:77px;">
		
		</div>
		
		
		
		<div id="content">
	
	
			
			
			<div id="map">
			
			
			
			
			<img src="sap_map_7202.png" usemap="#sap" style="width=85%" >
			
			<map id="usa_image_map" name="sap">

  
   


<span title="First Finger Spine Stairs">

<area value="First Finger Spine Stairs" href="#" shape="poly" 

coords="118.18000030517578,45.269989013671875,119.08999633789062,85.26998901367187,229.54998779296875,85.26998901367187,229.54998779296875,59.82

000732421875,262.72998046875,59.3599853515625,262.72998046875,45.269989013671875,223.63999938964844,45.72998046875,223.17999267578125,41.6399841

30859375,154.5500030517578,41.17999267578125,154.5500030517578,45.269989013671875" />
</span>    
	
	
<span title="Second Finger Spine Stairs">	
    <area value="Second Finger Spine Stairs" href="#" shape="poly" 

coords="458.8599853515625,45.72998046875,458.4100036621094,85.72998046875,566.1400146484375,85.26998901367187,566.1400146484375,59.8200073242187

5,593.8599853515625,59.3699951171875,593.4099731445312,41.17999267578125,515.6799926757812,41.639984130859375,515.6799926757812,45.2699890136718

75" />
</span>

<span title="Finger One Stairs">
    <area value="Finger One Stairs" href="#" shape="poly" 

coords="167.72999572753906,428.53997802734375,167.26998901367187,494.45001220703125,179.5500030517578,494.45001220703125,179.5500030517578,538.0

899658203125,219.54998779296875,538.0899658203125,219.54998779296875,456.26995849609375,189.5500030517578,456.26995849609375,190,428.0899658203125" />


</span>


<span title="Finger Two Stairs">
<area value="Finger Two Stairs" href="#" shape="poly" 

coords="540.9099731445312,399,571.8200073242187,399,571.8200073242187,445.3599853515625,610,445.3599853515625,610.4500122070312,549.72998046875,

558.6400146484375,550.72998046875,558.6400146484375,493.4599609375,540.4500122070312,493.4599609375" />
</span>

<span title="Third Finger Spine Stairs">
<area value="Third Finger Spine Stairs" href="#" shape="poly" 

coords="882.72998046875,46.720001220703125,882.72998046875,86.26998901367187,986.8200073242187,85.80999755859375,986.8200073242187,63.0899963378

90625,1020.449951171875,63.53997802734375,1020.449951171875,45.80999755859375,986.3599853515625,46.269989013671875,986.3599853515625,42.17999267

578125,910,42.6300048828125,909.5399780273437,46.269989013671875" />
</span>



<span title="Third Finger Stairs">
   <area value="Third Finger Stairs" href="#" shape="poly" coords="935.449951171875,399.90997314453125,965.449951171875,400.3599853515625,965.449951171875,439.45001220703125,996.8200073242187,439,996.3599853515625,538.5399780273437,951.3599853515625,538.5399780273437,951.8200073242187,494.90997314453125,935,493.53997802734375" />
</span>

<span title="Fionn Mac Cumhaill">
    <area value="Fionn Mac Cumhaill" href="#" shape="poly" coords="179.5500030517578,614.449951171875,179.5500030517578,636.2699584960937,197.26998901367187,636.719970703125,197.26998901367187,671.2699584960937,307.2699890136719,670.3599853515625,307.2699890136719,614.9099731445312" />
</span>


<span title="Cormac Mac Airt">	
	<area value="Cormac Mac Airt" href="#" shape="poly" 

coords="558.8599853515625,604.3699951171875,558.8599853515625,635.2799682617187,576.5899658203125,635.72998046875,576.5899658203125,660.27996826

17187,593.8599853515625,660.2799682617187,593.8599853515625,669.3699951171875,668.8599853515625,669.3699951171875,668.8599853515625,660.27996826

17187,689.7699584960937,660.2799682617187,689.7699584960937,636.1900024414062,702.5,635.72998046875,702.5,604.3699951171875" />

</span>

<span title="Children of Lir">
  <area value="Children of Lir" href="#" shape="poly" 

coords="952.72998046875,604.8999633789062,1081.8199462890625,605.8099975585937,1081.8199462890625,636.2699584960937,1068.6400146484375,636.26995

84960937,1069.0899658203125,661.2699584960937,1048.6400146484375,661.719970703125,1048.179931640625,669,986.8200073242187,669,986.3599853515625,

661.2699584960937,969.5399780273437,660.8099975585937,969.0899658203125,636.719970703125,952.2699584960937,636.2699584960937" />
</span>


<span title="Liam Ryan Office">
     <area value="Liam Ryan" href="#" shape="poly" coords="1068.6400146484375,117.6300048828125,1020.9099731445312,117.6300048828125,1020.449951171875,151.26998901367187,1069.0899658203125,151.72000122070312,1068.6400146484375,117.6300048828125,1020.9099731445312,118.08999633789062,1020.449951171875,151.26998901367187,1067.72998046875,151.72000122070312" />
</span>

<span title="Mulach Ide 1">
    <area value="Mullach Ide 1" href="#" shape="poly" coords="585.4500122070312,156.26998901367187,618.1799926757812,156.26998901367187,618.6400146484375,189.44998168945312,585.4500122070312,188.53997802734375" />
</span>

<span title="Mulach Ide 2">
	  <area value="Mullach Ide 2" href="#" shape="poly" 

coords="549.5499877929687,155.81997680664062,549.5499877929687,189.44998168945312,585.4500122070312,189.44998168945312,585.4500122070312,156.269

98901367187" />
</span>

<span title="Mulach Ide 3">
 <area value="Mullach Ide 3" href="#" shape="poly" 

coords="515.9099731445312,156.72998046875,515.9099731445312,189.44998168945312,549.5499877929687,190.3599853515625,550,156.26998901367187" />
</span>

<span title="Mulach Ide 4">
    <area value="Mullach Ide 4" href="#" shape="poly" coords="458.6399841308594,114.3699951171875,459.0899963378906,144.3699951171875,494.0899963378906,144.3699951171875,495,114.3699951171875" />
</span>

<span title="Mulach Ide 5">
 <area value="Mullach Ide 5" href="#" shape="poly" 

coords="458.6399841308594,85.27999877929687,458.17999267578125,114.3699951171875,494.0899963378906,114.3699951171875,494.54998779296875,85.72998046875" />
</span>

<span title="Tea Station - Middle Finger">
  <area value="Tea Station - Middle Finger" href="#" shape="poly" 

coords="565.4500122070312,59.3599853515625,565.4500122070312,85.72998046875,594.0899658203125,85.72998046875,593.1799926757812,59.3599853515625" 

/>
</span>

<span title="An Tain">
<area value="An Tain" href="#" shape="poly" 

coords="571.8200073242187,398,571.8200073242187,444.82000732421875,610.4500122070312,444.82000732421875,610.9099731445312,398" />
</span>

<span title="Fir Bolg">
    <area value="Fir Bolg" href="#" shape="poly" coords="611.3599853515625,399.45001220703125,610.9099731445312,431.719970703125,647.72998046875,431.26995849609375,646.8200073242187,399.45001220703125" />
</span>

<span title="Tea Station - First Finger">
	 <area value="Tea Station - First  Finger" href="#" shape="poly" 

coords="230,60.82000732421875,230,86.72998046875,262.2699890136719,86.72998046875,262.72998046875,60.3599853515625" />
</span>

<span title="Creidhne">
<area value="Creidhne" href="#" shape="poly" 

coords="189.5500030517578,429,189.5500030517578,456.719970703125,219.54998779296875,456.719970703125,219.54998779296875,428.53997802734375" />
</span>

<span title="Grainne Mhaol"
<area value="Grainne Mhaol" href="#" shape="poly" 

coords="219.54998779296875,427.0899658203125,220,455.27996826171875,248.63999938964844,455.27996826171875,248.17999267578125,427.0899658203125" 

/>
</span>

<span title="Teamhair">
    <area value="Teamhair" href="#" shape="poly" 

coords="965.449951171875,398.90997314453125,965.9099731445312,438.4599609375,996.8200073242187,438.4599609375,996.3599853515625,398.90997314453125" />
</span>

<span title="Gaoth Dobhair 1">
  <area value="Gaoth Dobhair 1" href="#" shape="poly" 

coords="203.63999938964844,153.45999145507812,203.63999938964844,189.3699951171875,235.4499969482422,189.3699951171875,235.4499969482422,153.459

99145507812" />
</span>

<span title="Gaoth Dobhair 2">
  <area value="Gaoth Dobhair 2" href="#" shape="poly" 

coords="170.4499969482422,153.45999145507812,170.4499969482422,188.91000366210937,203.63999938964844,189.3599853515625,203.17999267578125,153" 

/>
</span>

<span title="Gaoth Dobhair 3">
 <area value="Gaoth Dobhair 3" href="#" shape="poly" 

coords="136.8199920654297,154.44998168945312,136.36000061035156,189.91000366210937,170.4499969482422,189.91000366210937,170.4499969482422,154.44

998168945312" />
</span>

<span title="Gaoth Dobhair 4">
   <area value="Gaoth Dobhair 4" href="#" shape="poly" 

coords="137.27000427246094,123.53997802734375,136.8199920654297,153.53997802734375,170.4499969482422,154.44998168945312,170.4499969482422,123.08

999633789062" />
</span>

<span title"Cath Chnucha">
<area value="Cath Chnucha" href="#" shape="poly" 

coords="262.72998046875,45.279998779296875,262.72998046875,85.27999877929687,315.4499816894531,85.27999877929687,315.4499816894531,45.279998779296875" />
</span>

<span title="Lia Fail">
<area value="Lia Fail" href="#" shape="poly" 

coords="262.72998046875,85.72998046875,262.72998046875,120.26998901367187,315.4499816894531,119.81997680664062,315.4499816894531,85.26998901367187" />
</span>

<span title="An Bradan Feasa">
<area value="An Bradan Feasa" href="#" shape="poly" 

coords="996.3599853515625,399.90997314453125,996.3599853515625,431.26995849609375,1027.27001953125,431.26995849609375,1027.72998046875,400.3599853515625" />
</span>

<span title="MM">
    <area value="MM" href="#" shape="poly" 
coords="559.0899658203125,551.2699584960937,559.0899658203125,605.3599853515625,610,605.3599853515625,610.4500122070312,551.2699584960937" />
</span>

<span title="Fi-Co">
<area value="Fi-Co" href="#" shape="poly" 

coords="647.2699584960937,431.719970703125,647.2699584960937,604.9099731445312,702.2699584960937,605.3599853515625,702.2699584960937,432.0999755

859375" />
</span>

<span title="Clann Chaoilte 1">
 <area value="Clann Chaoilte 1" href="#" shape="poly" 

coords="982.2699584960937,159,982.72998046875,190.80999755859375,1006.3599853515625,189.89999389648437,1005.449951171875,159" />
</span>

<span title="Clann Chaoilte 2">
 <area value="Clann Chaoilte 2" href="#" shape="poly" 

coords="953.1799926757812,158.53997802734375,982.72998046875,159,982.72998046875,190.3599853515625,952.72998046875,190.3599853515625" />
</span>

<span title="Clann Chaoilte 3">
 <area value="Clann Chaoilte 3" href="#" shape="poly" 

coords="920,157.54998779296875,920,188.91000366210937,952.2699584960937,189.81997680664062,952.72998046875,157.54998779296875" />
</span>

<span title="Tea Station - Third Finger">
  <area value="Tea Station Third Finger" href="#" shape="poly" 

coords="986.8200073242187,62.54998779296875,1020.449951171875,62.100006103515625,1020.9099731445312,85.27999877929687,986.8200073242187,85.27999

877929687" />
</span>

<span title="NW Tools">
    <area value="NW Tools" href="#" shape="poly" 

coords="1081.8199462890625,443.53997802734375,1041.8199462890625,443.53997802734375,1041.8199462890625,605.3599853515625,1081.8199462890625,604.

9099731445312" />
</span>

<span title="NW Systems">
    <area value="NW Systems" href="#" shape="poly" 

coords="995.8099975585937,538.5399780273437,996.2699584960937,605.3599853515625,952.6300048828125,604.9099731445312,953.0899658203125,538.539978

0273437" />
</span>

<span title="ALM/Run">
<area value="ALM/Run" href="#" shape="poly" 

coords="691.8200073242187,57.6300048828125,730,58.089996337890625,729.0899658203125,136.63998413085937,691.3599853515625,135.72998046875" />
</span>

<span title="HANA">
 <area value="HANA" href="#" shape="poly" 

coords="738.6399536132812,85.3599853515625,759.0899658203125,85.3599853515625,759.0899658203125,120.72998046875,738.6399536132812,120.72998046875" />
</span>

<span title="MCC">
<area value="MCC" href="#" shape="poly" 

coords="771.8200073242187,84.44998168945312,772.2699584960937,121.63998413085937,842.3599853515625,123,842.8099975585937,84.3699951171875" />
</span>
</div>




</map>



	</div> 
		
		
		
		
		
		
		
		
		
		
			<div id="forms">
	<center>
		
		
		
		<div id="hidden" style="visibility: hidden;">
		<form >
			<select id='boundList' name="listlist"  >

	
			<option> </option>
			
			
		
			
			</select>
			</form>
			
			</div>
			</br>
		<center> <label> <b> Meeting Rooms:  </b> </label> </center>
		

		
		
		
			
			<form  id='boundList'  > 
			
			<select id='boundList' name="team"    >
			<option>Select Room</option>
			<option value="An Bradan Feasa">An Bradan Feasa</option>
			<option value="An Tain">An Tain</option>
			<option value="Cormac Mac Airt">Cormac Mac Airt</option>
			<option value="Children of Lir">Children of Lir</option>
			<option value="Creidhne">Creidhne</option>
			<option value="Cath Chnucha">Cath Chnucha</option>
			<option value="Clann Chaoilte 1">Clann Chaoilte 1</option>
			<option value="Clann Chaoilte 2">Clann Chaoilte 2</option>
			<option value="Clann Chaoilte 3">Clann Chaoilte 3</option>
			<option value="Fionn Mac Cumhaill">Fionn Mac Cumhaill</option>
			<option value="Fir Bolg">Fir Bolg</option>	
			<option value="Gaoth Dobhair 1">Gaoth Dobhair 1</option>
			<option value="Gaoth Dobhair 2">Gaoth Dobhair 2</option>
			<option value="Gaoth Dobhair 3">Gaoth Dobhair 3</option>
			<option value="Gaoth Dobhair 4">Gaoth Dobhair 4</option>
			<option value="Grainne Mhaol">Grainne Mhaol</option>
			<option value="Lia Fail">Lia Fail</option>
			<option value="Mullach Ide 1">Mullach Ide 1</option>
			<option value="Mullach Ide 2">Mullach Ide 2</option>
			<option value="Mullach Ide 3">Mullach Ide 3</option>
			<option value="Mullach Ide 4">Mullach Ide 4</option>
			<option value="Mullach Ide 5">Mullach Ide 5</option>
			<option value="Teamhair">Teamhair</option>
			
			
				
			
		
			
			
		
			
			</select>
			
			</form>
			<br/>
			
	
		<center> <label> <b> Team Select: </b> </label> </center>

		
		
		<form  id='boundList' action="main.php#innerinfo" target="iframe"    method="post"  > 
			
			<select  name="team" action="main.php#innerinfo" target="iframe"   onChange="this.form.submit()"  >
					<option>Select Team</option>
			<option value="NW Tools">NW Tools</option>
			<option value="NW Systems">NW Systems</option>
			<option value="MM/SRM">MM/SRM</option>
			<option value="ERP FIN">ERP FIN</option>
			
			</select>
			
			
			</form>
			
</br>
			<a class="button" href="main2.php">Clear all</a>
			</br>
		    <a class="button2"  href="main.php">To Ground Floor</a>
		
		
		</br>
		<hr>
		</center>
		</div>
		
		
		
		
		
		
		
		
			<div id="sidebar">	

		<iframe class="noscrolling" name="iframe"   src="main2.php#innerinfo" frameborder="0"   scrolling="no" ></iframe>

		<!-- this code takes the value selected from dropdown list
		and based on value chosen data from the db will be displayed -->
		
		<center>
		<div id="innerinfo" >
		<?php

		
			//checking if form was submitted
			if(!empty( $_POST['team'] ) ){
					
				$dropdownValue = $_POST['team'];
					
				$con = mysqli_connect("localhost","root","","teams");

				if (mysqli_connect_errno($con))
				{
					
				echo "Failed to connect to MySQL: ".mysqli_connect_error();
					
				}

					
				if( empty( $dropdownValue ) || $dropdownValue == "null" )
					die( "You must select something from the dropdown! Please go back and try again." );
			
			
				if(!empty($dropdownValue))
				{
					
					
					$sql = " SELECT `employees`.`Name`, `employees`.`Team`,`managers`.`Managers Name` FROM `employees`, `managers` WHERE `employees`.`Team` = '$dropdownValue' AND `managers`.`Team` = '$dropdownValue'";
					$result = $con->query($sql);
						
					
					
						echo "<table border=1><tr><th>Manager</th><th>Team</th></tr>";
					while($row = $result->fetch_assoc()) {
						echo "<tr><td><center>".$row["Managers Name"]."</center></td><td><center>".$row["Team"]."</center></td></tr></table>";
					
					echo"</br>";
					
					
					echo "<table border=1><tr><th>Employees</th></tr>";
					while($row = $result->fetch_assoc()) {
						echo "<tr><td><center>".$row["Name"]."</center></td></tr>";
					}
					echo "</table>";
					}
				}
					//while($row = $result->fetch_assoc()) {
					//	echo "<tr><td>".$row["Managers Name"]."</td><td>".$row["Team"]."</td><td>".$row["Name"]."</td></tr>";
					//}
					//echo "</table>";
					//}
					
					if(!mysqli_query($con,$sql))
					{
						die('Error: ' . mysqli_error($con));
						
					}

				mysqli_close($con);

				}

		?>
		
			</div>
	
	  
	 
		
	
		
			
			
	</div>	<!--Sidebar close div -->
		</center>
		
		
		
	

</div>

</div>

</body>


</html>