<!-- Author - Yomi, Keith -->

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 

<html xmlns = "http://www.w3.org/1999/xhtml">

<head>

<title> Map Page </title>

<script type="text/javascript" src="javascript/Function.js"></script>
<link href="css/style3.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="JavaScript/jquery.min.js"></script>
<link href="css/style2.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="JavaScript/jquery.imagemapster.js"></script>
<script type="text/javascript" src="JavaScript/FunctionMap.js"></script>



</head>




<body>
 <div class="container">
 
<div id="wrapper">



		<div id="header"> 
		
		<img src="sap.png" alt="Logo" style="width:151px;height:77px;">
		
		</div>
		
		
		
		
		
		
		
	
				
		

		<!-- team selector form -->
		
		

		
	
		
		
		
		
		
		
	
	
		
		
		
		
	<div id="content">
			
			<div id="map">
			
			<img id="SAP" src="sap_map_720.png" usemap="#sap" style="width=60%">
			
			
			

			<map id="usa_image_map" name="sap">
			
			<span title="BW/HCM">
		<area class="selected" name="BW/HCM" value="BW/HCM" href="#" shape="poly"  coords="558.8599853515625,550.5700073242187,702.8599853515625,552.2899780273437,703.4299926757812,635.7099609375,689.7099609375,636.2899780273437,688.5700073242187,659.7099609375,669.1400146484375,660.8599853515625,668,668.8599853515625,593.7099609375,669.4299926757812,593.7099609375,660.2899780273437,577.1400146484375,660.2899780273437,576.5700073242187,635.7099609375,558.8599853515625,635.1399536132812" /> </span>

		<span title="SD">
		<area  value="SD" href="#" full="SD" shape="poly" coords="612,551.1399536132812,700.5700073242187,551.7099609375,700.5700073242187,452.27996826171875,612,452.8599853515625" />
		</span>

		<span title="Internal Support">
		<area  value="Internal Support" href="#" full="Internal Support" shape="poly" coords="541.1400146484375,398.57000732421875,541.1400146484375,207.13998413085937,689.7099609375,207.70999145507812,689.1400146484375,399.1400146484375" />
		</span>

		<span title="Muirne">
		<area value="Muirne" href="#" shape="poly" 
		coords="571.4299926757812,399,610.2799682617187,399.57000732421875,610.8499755859375,445.8499755859375,571.4299926757812,445.27996826171875" />
		</span>


		<area value="GroundStairsMiddleFinger" class="selected" href="#" shape="poly" coords="541.7099609375,399.5799560546875,570.8599853515625,399.5799560546875,571.4299926757812,445.28997802734375,610.8599853515625,445.8599853515625,610.8599853515625,551.5799560546875,558.2899780273437,551.5799560546875,558.8599853515625,494.42999267578125,540.5700073242187,492.719970703125" />


		<span title="Bran agus Sceolang">
		<area value="Bran agus Sceolang" href="#" shape="poly" 
		coords="639.4299926757812,398,640,428.27996826171875,672.5700073242187,428.8499755859375,672.5700073242187,398" />
		</span>

		<Span title="Costa">
		<area value="Costa" href="#" shape="poly" coords="472,144.8599853515625,472,187.70999145507812,588,187.13998413085937,588.5700073242187,145.42999267578125" />
		</span>

		<span title="Naoise">
		<area value="Naoise" href="#" shape="poly" coords="257.1399841308594,501.42999267578125,256.57000732421875,529.4299926757812,307.42999267578125,529.4299926757812,307.42999267578125,501.42999267578125" />
		</span>

		<span title="HR Lounge">
		<area value="HR Lounge" href="#" shape="poly" coords="256.57000732421875,530.4299926757812,256.57000732421875,571.5700073242187,306.8500061035156,572.1399536132812,307.42999267578125,530.4299926757812" />
		 </span>
		 

		<area value="GroundStairsFirstFinger" href="#" shape="poly"
		coords="168,428.7099609375,167.42999267578125,493.8499755859375,179.42999267578125,495,180,538.4299926757812,220,539,220,428.1400146484375" />

		<span title="Facilities">
		<area value="Facilities" href="#" shape="poly" 
		coords="252,362.42999267578125,294.2799987792969,361.8499755859375,294.2799987792969,385.27996826171875,307.42999267578125,385.27996826171875,307.42999267578125,444.7099609375,261.7099914550781,444.7099609375,261.7099914550781,404.1400146484375,251.42999267578125,403.57000732421875" />
		</span>

		<span title="Local IT">
		<area value="Local IT" href="#" shape="poly" 
		coords="168,188.8499755859375,217.70999145507812,189.41998291015625,217.70999145507812,371.7099609375,167.42999267578125,371.7099609375" />
		</span>

		<span title="Nuada">
		<area value="Nuada" href="#" shape="poly" 
		coords="253.13999938964844,242.56997680664062,294.8500061035156,242.56997680664062,294.2799987792969,338.57000732421875,252.5699920654297,338.57000732421875" />
		</span>

		<span title="Kitchen">
		<area value="Kitchen" href="#" shape="poly" 
		coords="39.43000030517578,46.42999267578125,118.8499984741211,46.42999267578125,118.8499984741211,86.42999267578125,100.56999969482422,87,101.70999908447265,191,38.849998474121094,190.42999267578125" />
		</span>

		<area value="StairsKitchen" href="#" shape="poly" 
		coords="118.8499984741211,45.42999267578125,154.27999877929687,46,154.84999084472656,41.42999267578125,224,41.42999267578125,223.42999267578125,44.290008544921875,262.2799987792969,44.8599853515625,262.8500061035156,85.42999267578125,118.27999877929687,84.8599853515625" />

		<area value="Stairs opposite Costa" href="#" shape="poly" 
		coords="458.28997802734375,44.8599853515625,515.4299926757812,44.8599853515625,516,40.8599853515625,593.1400146484375,41.42999267578125,593.1400146484375,85.42999267578125,458.8599853515625,84.8599853515625" />

		<span title="Cleaners Room">
		<area value="Cleaners Room" href="#" shape="poly" 
		coords="593.7099609375,45.42999267578125,630.2799682617187,45.42999267578125,630.2799682617187,85.42999267578125,593.7099609375,84.8599853515625" />
		</span>

		<span title="Comms Room">
		<area value="Comms Room" href="#" shape="poly" coords="675.4299926757812,45.850006103515625,675.4299926757812,86.42999267578125,754.8499755859375,86.42999267578125,754.2799682617187,46.42999267578125" />
		</span>

		<span title="Telepresence Room">
		<area value="Telepresence Room" href="#" shape="poly" coords="755.0999755859375,46.42999267578125,823.0999755859375,46.42999267578125,823.0999755859375,86.42999267578125,755.0999755859375,86.42999267578125" />
		 </span>
		 
		 <span title="Temp. Training Room">
		<area value="Temp. Training Room" href="#" shape="poly" coords="823.4299926757812,46.57000732421875,823.4299926757812,85.42999267578125,909.1499633789062,86,908.5799560546875,46" />
		</span>

		<area value="Stairs beside Medical Room" href="#" shape="poly" 
		coords="909.7099609375,40.8599853515625,910.2899780273437,85.42999267578125,1021.1399536132812,85.42999267578125,1021.1399536132812,45.42999267578125,986.8599853515625,44.8599853515625,986.2899780273437,40.8599853515625" />

		<span title="Medical Room">
		<area value="Medical Room" class="selected" href="#" shape="poly" 
		coords="1020.5799560546875,46,1020.5799560546875,84.8599853515625,1044.5799560546875,84.8599853515625,1068.5799560546875,84.8599853515625,1068.5799560546875,66.57000732421875,1068.5799560546875,46" />
		</span>

		<span title="Showers">
		<area value="Showers" href="#" shape="poly" coords="648.5700073242187,136.8599853515625,648.5700073242187,189.42999267578125,734.8499755859375,188.8599853515625,734.2799682617187,135.72000122070312" />
		</span>

		<span title ="Production Room">
		<area value="Production Room" href="#" shape="poly" 
		coords="734.8499755859375,136.28997802734375,734.2799682617187,190,784.5700073242187,189.42999267578125,784.5700073242187,135.70999145507812" />
		</span>

		<span title = "Oisin">
		<area value="Oisin" href="#" shape="poly" 
		coords="804.8099975585937,137.27999877929687,804.8099975585937,190.42999267578125,869.3800048828125,190.42999267578125,869.9599609375,137.27999877929687" />
		</span>

		<span title="Tuan McCairog">
		<area value="Tuan McCairog" href="#" shape="poly" coords="869.9599609375,136.28997802734375,900.8099975585937,136.28997802734375,901.3800048828125,189.42999267578125,869.9599609375,189.42999267578125" />
		</span>

		<span title="Aonghus Og">
		<area value="Aonghus Og" href="#" shape="poly" coords="901.1399536132812,137.27999877929687,901.1399536132812,163.56997680664062,934.8599853515625,163.56997680664062,935.4299926757812,136.70999145507812" />
		</span>

		<span title="Nas na Riogh">
		<area value="Nas na Riogh" href="#" shape="poly" 
		coords="901.1399536132812,162.56997680664062,901.1399536132812,189.42999267578125,935.4299926757812,189.42999267578125,934.8599853515625,162" />
		</span>

		<span title="An Craobh Ruadh">
		<area value="An Craobh Ruadh" href="#" shape="poly" 
		coords="967.4299926757812,400.8599853515625,994.8599853515625,400.8599853515625,994.8599853515625,436.8599853515625,967.4299926757812,436.8599853515625" />
		</span>

		<area value="GroundStairsThirdFinger" href="#" shape="poly" 
		coords="935.4299926757812,399.719970703125,965.719970703125,399.14996337890625,965.719970703125,438.57000732421875,996,438.57000732421875,996.5799560546875,537.4299926757812,953.1499633789062,536.8599853515625,952.5799560546875,494,936,492.8599853515625" />

		<span title="Na Fianna">
		<area value="Na Fianna" href="#" shape="poly" coords="1021.719970703125,399.7099609375,1021.1399536132812,428.27996826171875,1051.429931640625,428.27996826171875,1050.2899169921875,399.7099609375" />
		</span>

		<span title="Cu Chulainn">
		<area value="Cu Chulainn" href="#" shape="poly" 
		coords="953.1399536132812,605.2899780273437,1081.1400146484375,605.2899780273437,1081.719970703125,636.719970703125,1069.1400146484375,636.1399536132812,1068.5699462890625,661.2899780273437,1048.5699462890625,661.2899780273437,1048.5699462890625,669.2899780273437,986.2899780273437,669.2899780273437,986.2899780273437,660.719970703125,969.719970703125,660.719970703125,969.1399536132812,636.719970703125,952.5700073242187,635.5700073242187" />
		</span>

		<span title="NW DBOS HANA">
		<area value="NW DBOS HANA" href="#" shape="poly" 
		coords="996.5799560546875,536.8599853515625,997.1499633789062,604.2899780273437,953.1499633789062,604.2899780273437,952.5799560546875,536.8599853515625" />
		</span>

		<span title="HANA">
		<area value="HANA" href="#" shape="poly" 
		coords="1041.1500244140625,540.719970703125,1041.1500244140625,604.1399536132812,1079.429931640625,604.1399536132812,1080,540.1399536132812" />
		</span>

		<span title="RCA Backoffice">
		<area value="RCA BackOffice" href="#" shape="poly" 
		coords="1081.719970703125,510,1081.719970703125,528.2899780273437,1043.429931640625,528.8599853515625,1042.8599853515625,511.13995361328125" />
		</span>

		<span title="RCA/SolMan">
		<area value="RCA/SolMan" href="#" shape="poly" 
		coords="996,495.57000732421875,1082.2899169921875,496.13995361328125,1081.719970703125,382.42999267578125,1068.5799560546875,383,1068.5799560546875,365.8499755859375,1020.5799560546875,366.42999267578125,1021.1499633789062,399.57000732421875,1051.429931640625,400.1400146484375,1051.429931640625,428.7099609375,996.5799560546875,428.7099609375" />
		</span>

		<span title = "PLM/MAN">
		<area value="PLM/MAN" href="#" shape="poly" 
		coords="1068,243.72000122070312,1068.5799560546875,323.719970703125,1023.4299926757812,324.8599853515625,1022.8599853515625,246" />
		</span>

		<span title="CRM">
		<area value="CRM" href="#" shape="poly" 
		coords="1006.2899780273437,273.42999267578125,1066.2899169921875,275.1400146484375,1066.2899169921875,87.13998413085937,1008.5799560546875,87.70999145507812" />
		</span>

		<span title="EP/XI/J2EE">
		<area value="EP/XI/J2EE" href="#" shape="poly" coords="935.4299926757812,189.42999267578125,964.5799560546875,189.42999267578125,964.5799560546875,135.72000122070312,987.4299926757812,136.28997802734375,987.4299926757812,398.57000732421875,936,398.57000732421875" />
		</span>
		
		</div>
		
		
		</map>
<div id="boxtest">
</div>

	</div> 
	
	
	<div id="forms">
	<center>
		
		
		
		<div id="hidden" style="visibility: hidden;">
		<form >
			<select id='boundList' name="listlist"  >

	
			<option> </option>
			
			
		
			
			</select>
			</form>
			
			</div>
			</br>
		<center> <label> <b> Meeting Rooms:  </b> </label> </center>
		

		
		
		
			
			<form  id='boundList'  > 
			
			<select id='boundList' name="team"    >
			<option>Select Room</option>
			<option value="An Craobh Ruadh">An Craobh Ruadh</option>
			<option value="Aonghus Og">Aonghus Og</option>
			<option value="Bran agus Sceolang">Bran agus Sceolang</option>
			<option value="Cu Chulainn">Cu Chulainn</option>
			<option value="HR Lounge">HR Lounge</option>
			<option value="Muirne">Muirne</option>
			<option value="Na Fianna">Na Fianna</option>
			<option value="Naoise">Naoise</option>
			<option value="Nas na Riogh">Nas na Riogh</option>
			<option value="Nuada">Nuada</option>
			<option value="Oisin">Oisin</option>
			<option value="Tuan McCairog">Tuan McCairog</option>
			
		
			
			</select>
			
			</form>
			<br/>
			
	
		<center> <label> <b> Team Select: </b> </label> </center>

		
		
		<form  id='boundList' action="main.php#innerinfo" target="iframe"    method="post"  > 
			
			<select  name="team" action="main.php#innerinfo" target="iframe"   onChange="this.form.submit()"  >
			<option >Select Team</option>
			<option value="BW/HCM">BW/HCM</option>
			<option value="CRM">CRM</option>
			<option value="EP/XI/J2EE">EP/XI/J2EE</option>
			<option value="NW DBOS HANA">NW DBOS HANA</option>	
			<option value="PLM/MAN">PLM/MAN</option>
			<option value="RCA/SolMan">RCA/SolMan</option>
			<option value="SD">SD TEAM</option>
			
			
			</select>
			
			
			</form>
			
</br>
			<a class="button" href="main.php">Clear all</a>
			</br>
			<a class="button2"  href="main2.php">To Upper Floor</a>
		
		</br>
		<hr>
		</center>
		</div>
		
		
		<div id="sidebar">	

		<iframe class="noscrolling" name="iframe"   src="main.php#innerinfo" frameborder="0"   scrolling="no" ></iframe>

		<!-- this code takes the value selected from dropdown list
		and based on value chosen data from the db will be displayed -->
		
		<center>
		<div id="innerinfo" >
		<?php

		
			//checking if form was submitted
			if(!empty( $_POST['team'] ) ){
					
				$dropdownValue = $_POST['team'];
					
				$con = mysqli_connect("localhost","root","","teams");

				if (mysqli_connect_errno($con))
				{
					
				echo "Failed to connect to MySQL: ".mysqli_connect_error();
					
				}

					
				if( empty( $dropdownValue ) || $dropdownValue == "null" )
					die( "You must select something from the dropdown! Please go back and try again." );
			
			
				if(!empty($dropdownValue))
				{
					
					
					$sql = " SELECT `employees`.`Name`, `employees`.`Team`,`managers`.`Managers Name` FROM `employees`, `managers` WHERE `employees`.`Team` = '$dropdownValue' AND `managers`.`Team` = '$dropdownValue'";
					$result = $con->query($sql);
						
					
					
						echo "<table border=1><tr><th>Manager</th><th>Team</th></tr>";
					while($row = $result->fetch_assoc()) {
						echo "<tr><td><center>".$row["Managers Name"]."</center></td><td><center>".$row["Team"]."</center></td></tr></table>";
					
					echo"</br>";
					
					
					echo "<table border=1><tr><th>Employees</th></tr>";
					while($row = $result->fetch_assoc()) {
						echo "<tr><td><center>".$row["Name"]."</center></td></tr>";
					}
					echo "</table>";
					}
				}
					//while($row = $result->fetch_assoc()) {
					//	echo "<tr><td>".$row["Managers Name"]."</td><td>".$row["Team"]."</td><td>".$row["Name"]."</td></tr>";
					//}
					//echo "</table>";
					//}
					
					if(!mysqli_query($con,$sql))
					{
						die('Error: ' . mysqli_error($con));
						
					}

				mysqli_close($con);

				}

		?>
		
			</div>
	
	  
	 
		
	
		
			
			
	</div>	<!--Sidebar close div -->
	</center>

</div>

</div>




</body>


</html>